define({
  "name": "Multichain API",
  "version": "1.0.0",
  "description": "API List for multichain",
  "template": {
    "forceLanguage": "en"
  },
  "sampleUrl": false,
  "defaultVersion": "0.0.0",
  "apidoc": "0.3.0",
  "generator": {
    "name": "apidoc",
    "time": "2018-02-07T11:07:11.933Z",
    "url": "http://apidocjs.com",
    "version": "0.17.6"
  }
});
