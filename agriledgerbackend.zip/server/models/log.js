'use strict';

module.exports = function(Log) {

};
