'use strict';

module.exports = function(District) {

};
