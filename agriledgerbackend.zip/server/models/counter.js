'use strict';

module.exports = function(Counter) {

};
