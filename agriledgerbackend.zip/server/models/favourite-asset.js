'use strict';

module.exports = function(Favouriteasset) {

};
