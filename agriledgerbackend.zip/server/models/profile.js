'use strict';
const Ajv = require('ajv');

const Schema=require('../validation/schema');
module.exports = function(Profile) {

};
