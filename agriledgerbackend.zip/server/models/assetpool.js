'use strict';


module.exports = function(Assetpool) {


};
