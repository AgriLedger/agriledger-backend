'use strict';

module.exports = function(Province) {

};
